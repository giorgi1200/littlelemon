//
//  Little_Lemons_OrderingApp.swift
//  Little Lemons Ordering
//
//  Created by Giorgi on 6/14/23.
//

import SwiftUI

@main
struct Little_Lemons_OrderingApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            Onboarding()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
