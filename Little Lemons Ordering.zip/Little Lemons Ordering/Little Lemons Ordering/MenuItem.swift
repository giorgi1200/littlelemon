//
//  MenuItem.swift
//  Little Lemons Ordering
//
//  Created by Giorgi on 6/16/23.
//

import Foundation

struct MenuItem: Decodable {
    let title: String
    let image: String
    let price: String
    let id: Int
    let description: String
    let category: String
}
