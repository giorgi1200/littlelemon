//
//  Menu.swift
//  Final Project
//
//  Created by Giorgi on 6/14/23.
//

import SwiftUI
import CoreData

struct Menu: View {
    @State private var menuList: MenuList?
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(entity: Dish.entity(), sortDescriptors: []) var dishes: FetchedResults<Dish>
    @State private var searchText = ""

    
        
    var body: some View {
            VStack {
                Text("My Restaurant App")
                    .font(.title)
                    .padding()
                
                Text("Location: Chicago")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .padding(.bottom)
                
                Text("Welcome to My Restaurant App! Enjoy exploring our menu and placing orders.")
                    .font(.body)
                    .padding()
                
                TextField("Search menu", text: $searchText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)
                
                let sortDescriptors = buildSortDescriptors()
                let fetchedObjects = FetchedObjects(predicate: buildPredicate(), sortDescriptors: sortDescriptors) { (dishes: [Dish]) in
                    List {
                        ForEach(dishes, id: \.objectID) { dish in
                            HStack {
                                Text("\(dish.title!) - $\(dish.price!)")
                                AsyncImage(url: URL(string: dish.image!)!) { image in
                                    image
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 50, height: 50)
                                } placeholder: {
                                    ProgressView()
                                }
                            }
                        }
                    }
                }
                
                fetchedObjects
                    .onAppear {
                        getMenuData()
                    }
            }
        }
        
        func buildPredicate() -> NSPredicate {
            if searchText.isEmpty {
                return NSPredicate(value: true)
            } else {
                return NSPredicate(format: "title CONTAINS[cd] %@", searchText)
            }
        }


    

    
    func buildSortDescriptors() -> [NSSortDescriptor] {
            return [NSSortDescriptor(key: "title", ascending: true, selector: #selector(NSString.localizedStandardCompare))]
        }
    
    private func getMenuData() {
        let persistence = PersistenceController.shared
        persistence.clear()
        
        let serverURLString = "https://raw.githubusercontent.com/Meta-Mobile-Developer-PC/Working-With-Data-API/main/menu.json"
        
        guard let url = URL(string: serverURLString) else {
            print("Invalid URL: \(serverURLString)")
            return
        }
        
        let request = URLRequest(url: url)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching menu data: \(error.localizedDescription)")
                return
            }
            
            if let data = data {
                do {
                    let decoder = JSONDecoder()
                    if let decodedMenuList = try? decoder.decode(MenuList.self, from: data) {
                        DispatchQueue.main.async {
                            self.menuList = decodedMenuList
                            convertAndSaveMenuItems(decodedMenuList.menu)
                        }
                    } else {
                        print("Failed to decode menu data")
                    }
                } catch {
                    print("Error decoding menu data: \(error.localizedDescription)")
                }
            } else {
                print("No data received")
            }
            
        }
        .resume()
    }
    
    private func convertAndSaveMenuItems(_ menuItems: [MenuItem]) {
        for menuItem in menuItems {
            let dish = Dish(context: viewContext)
            dish.title = menuItem.title
            dish.image = menuItem.image
            dish.price = menuItem.price
        }
        
        do {
            try viewContext.save()
        } catch {
            print("Error saving menu data to database: \(error.localizedDescription)")
        }
    }
}

struct Menu_Previews: PreviewProvider {
    static var previews: some View {
        Menu()
    }
}
