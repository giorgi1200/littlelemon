//
//  MenuList.swift
//  Little Lemons Ordering
//
//  Created by Giorgi on 6/16/23.
//

import Foundation

struct MenuList: Decodable {
    let menu: [MenuItem]
}
