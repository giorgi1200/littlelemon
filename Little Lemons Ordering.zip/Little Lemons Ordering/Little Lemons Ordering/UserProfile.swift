//
//  UserProfile.swift
//  Final Project
//
//  Created by Giorgi on 6/14/23.
//

import SwiftUI

struct UserProfile: View {
    let firstNameValue = UserDefaults.standard.string(forKey: kFirstName) ?? ""
    let lastNameValue = UserDefaults.standard.string(forKey: kLastName) ?? ""
    let emailValue = UserDefaults.standard.string(forKey: kEmail) ?? ""
    
    @Environment(\.presentationMode) var presentation
    var body: some View {
        VStack{
            Text("Personal information")
            Image("profile-image-placeholder")
            Text(firstNameValue)
            Text(lastNameValue)
            Text(emailValue)
            Button(action: {
                            UserDefaults.standard.set(false, forKey: kIsLoggedIn)
                            self.presentation.wrappedValue.dismiss()
                        }) {
                            Text("Logout")
                        }
                        Spacer()
            
        }
    }
}

struct UserProfile_Previews: PreviewProvider {
    static var previews: some View {
        UserProfile()
    }
}
